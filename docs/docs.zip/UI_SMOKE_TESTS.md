# 1.0.9 补充

当前可选界面回归51项，全部通过。新增归档保存标记的原生像素/状态验证、三语言引号与日期同行文案、自动备份去重/失败重试/丢失重建、添加请求拒绝/异常/回调失败/未确认详细弹窗和复制内容检查。普通JVM测试247项。

# 小组件编辑页启动回归

默认编译和原有JVM测试不使用此测试工具，不会新增APK运行依赖。下列检查只在显式传入init脚本时启用，首次会另外下载Robolectric及Android框架运行时包；流量不足时不运行即可。

```sh
./gradlew -I tools/ui-smoke.init.gradle :app:testDebugUnitTest --tests '*UiTest'
```

Windows使用`gradlew.bat`，其他参数相同；缓存完整后可添加`--offline`。测试源文件位于`tools/ui-smoke-tests`，不在常规测试源目录中；init脚本临时加入依赖、资源支持和测试源目录，不修改应用的依赖声明。

检查在Robolectric的Android13/API33环境中运行，包含：从真实小组件ID进入后建出三个标签、依次切换Small/Medium/Large、活动重建后保留选中尺寸，以及进入时不让EditText获取焦点。测试通过公开Activity入口加载真实事件，再执行异步仓库回调。

关键限制：Robolectric默认的TabHost和TabSpec替身跳过了系统标签布局加载，会掩盖本次错误。测试专门替换这两个默认替身，让标签构建走Android框架代码，同时保留测试框架对ViewGroup和资源的支持。它仍然不是模拟器或真机测试。

1.0.3错误复现：`TabHost(context)`不初始化标签布局资源，添加第一个带文字的标签时加载资源0，抛出`Resources.NotFoundException: Resource ID #0x0`。1.0.4改用`TabHost(context, null)`，经过带样式的初始化过程。三个尺寸的排版数据格式、用户数据和运行依赖不变。

Android框架实现可参见[TabHost.java](https://android.googlesource.com/platform/frameworks/base/+/refs/heads/main/core/java/android/widget/TabHost.java)。测试工具设置参考[Robolectric Getting Started](https://robolectric.org/getting-started/)。

1.0.5测试覆盖：原生RemoteViews跨Parcel还原、透明度/重叠/中心坐标、原生字体测量与字号上限、未选择禁用设置、绑定应用、带ID的添加成功回调、显式白色与默认色区分、事件编辑入口清理、JSON全文替换与原生滚动容器。字体测量用Robolectric Native Graphics。可选测试独立写入app/build-ui-smoke，避免测试类残留影响普通离线编译。

1.0.6新增：字重轴跨进程参数、真实粗细像素差异、顶栏保存、返回确认和不保存、不丢失异步保存结果、普通Activity最近任务标志。最终18项通过。

1.0.7新增：紧凑编辑行、预览固定/调整、文本选择着色、排版库捕获与归档、历史快照编辑/副本/删除、回滚日志、目录提供者覆盖/失败保留、应用前后台自动导出、桌面请求及查询阻塞期限、三列方形预览实际绘制。最终33项通过。

1.0.8：无改动返回、选择历史、字重步进/滑块、排版库元数据与导入保留绑定、日期/时间弹窗、完整存储按钮、文本池、自动备份Toast、跨午夜无Activity更新、预览控件复用与绘制、1.0.5原生预览请求协议。最终42项通过。
