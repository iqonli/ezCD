# 1.0.10 验证记录

2026-10-24。Gradle9.6.1 / AGP9.2.1 / JDK21.0.2 / SDK35 / Build Tools36.0.0；未增加运行依赖。

普通JVM测试249项、Android13/API33 Robolectric界面回归55项全部通过。assembleRelease、testDebugUnitTest、lintDebug成功；lint为0错误、368警告。源码资源和1000字重样式生成校验通过。

针对用户真实日志：baseline=298,299,302，pinSupported=true，请求返回true，MIUI成功回调widgetId=0但实际新增未绑定组件。现在无效ID会进入补绑定流程，在可靠基线之后只有一个新增ID时绑定该实例；不猜测多个候选，不覆盖旧组件。回归通过真实接收器广播，验证新ID303绑定成功、旧298/299/302均不受影响、没有失败弹窗。失去窗口焦点但仍在前台时，15秒等待上限恢复pending/按钮；离开Activity时暂停、回到前台重新等待。缺少创建快捷方式权限仍需用户在MIUI设置授权，本程序没有私自授予权限。

原生绘制像素验证归档图标位于整个画布右上角。重命名验证字段聚焦、全部选中、InputMethodManager显示普通键盘。事件卡片全部视图elevation=0，移除系统投影避免直角叠影。

色板回归验证事件默认、预设蓝、自定义蓝（同一个RGB但不同来源）的正确高亮；选择小组件自己的默认色会解除跟随。JSON可往返独立default色；事件自定义来源可往返存储及备份，并影响EventRevision。旧事件没有来源标记时无法恢复历史实际点击来源，只按颜色值推断。所有新参数标题14sp。新排版default需要1.0.10及以上；旧auto现在按跟随事件前景色解释。新默认排版普通文字用default保留默认外观。

APK：versionName1.0.10，versionCode11，minSdk26、targetSdk34、不可调试；401183字节，无原生ABI库，支持arm64-v8a。v2/v3签名、16KiB对齐、ZIP完整性及R8后1000字重样式保留通过。

APK SHA256：5a96a46d6379a6aac25a3a0f994baaa7761855858d285f1d5f16f44e52a6bb91

证书SHA256：d672ccba0f93424c5638f39ccee5ed24e8056e7ced76f0acc11377fa0c76e628，与1.0.6新签名以来一致。私钥未纳入源码。

尚未在用户的MIUI手机上实测；上述是针对日志复现的主机测试，不能代替真机结果。字体本次仅回答可行性，未增加字体选择/导入功能。
