# 添加到桌面与尺寸（1.0.16）

应用内的首页事件菜单、事件编辑页均打开 WidgetPinSetupActivity。编辑页沿用先保存后跳转的顺序。页面包含事件概要、自定义小组件大小、宽度与高度的 ±1／输入／格，以及添加按钮；进行中禁用尺寸修改，旋转保留请求快照和输入草稿。标准桌面的小组件列表／配置入口仍由桌面负责。

## 桌面范围

Android 标准 API 不向普通应用统一提供当前桌面网格列数、行数或空闲单元。`OPTION_APPWIDGET_MIN/MAX_WIDTH/HEIGHT` 是既有实例当前宽高范围，不能冒充桌面的总网格上限。

默认桌面为 com.miui.home 时，尝试读取系统表 `miui_home_screen_cells_size`。只接受有效的网格形式，权限错误、空值、未知格式均回退为未报告。该厂商键属于兼容探测，不保证所有 MIUI／HyperOS 版本都公开或采用相同语义。使用第三方桌面时，不把 MIUI 网格套用到第三方桌面。

UI 收到网格后按其列／行范围禁用加号和校验输入；未收到则提示最终由桌面确认，不根据屏幕像素猜网格。应用提供的预设定义覆盖每轴 1–16 格；这是构建时覆盖范围，和桌面的真实上限分开。若桌面报告超过 16 格，当前只能在应用预设覆盖范围内选择，后续可扩展生成脚本。

## 尺寸请求

Android 9/API28 起，使用 AppWidgetManager.updateAppWidgetProviderInfo 切换到该格数对应的 manifest 元数据，再调用标准 requestPinAppWidget。成功调用或抛出异常后都恢复默认 provider 定义；回调数据仍记录原始宽高，旋转不丢失选择。只有默认大小变化，Android 12+ 各定义的 minResizeWidth／Height 维持原值。

Android 12+ 使用 targetCellWidth／targetCellHeight。Android 9–11 使用官方旧尺寸模型近似的 dp 提示，格数可能随桌面单元尺寸不同而变化；Android 8.x 无动态 provider 元数据 API，控件固定 1 × 1 并说明添加后在桌面调整。预览 dp 是显示提示，不冒充从桌面获取的真实单元尺寸。最终是否接收、占格及可调整范围由桌面决定。

不调用 updateAppWidgetOptions 写入选择页的估算 dp；已添加实例继续按桌面尺寸报告绘制，避免把绘图尺寸误当成实际占格。既有 widget ID、绑定事件及 MIUI 零回调恢复逻辑保持。跨进程请求只传可解析、有限的格数；旧回调缺失格数时默认为 1 × 1。

生成定义：`python tools/generate-pin-sizes.py`；校验：追加 `--check`。生成的 XML 只使用现有布局、图标和配置活动，不增加 provider 组件或桌面列表中的重复条目。

## 快捷方式权限

标准 AppWidgetManager 支持检测只能说明桌面是否支持请求，不能等同于厂商私有权限已允许。对 MIUI／小米设备，兼容读取 AppOps 操作 10017：MODE_ALLOWED 为允许，MODE_IGNORED／ERRORED 为禁止，DEFAULT、询问及调用异常为未知。没有隐藏 API 绕过或自动授权。

明确禁止时页面显示提示，点击添加打开授权确认，用户可进入 MIUI 权限页；打开失败则回到系统应用详情。查询在独立的有限后台线程池中执行，未知或探测受阻不永久禁用按钮。旧反馈超时和复制诊断逻辑继续可用。第三方厂商不提供状态时，不能保证事先识别其私有开关。

协议常量和调用方式参考 Telegram 官方源码 XiaomiUtilities.java；这里只实现独立的兼容调用与状态分类，没有复制该项目的源文件。

## 来源

- https://developer.android.com/reference/android/appwidget/AppWidgetManager#updateAppWidgetProviderInfo(android.content.ComponentName,%20java.lang.String)
- https://developer.android.com/reference/android/appwidget/AppWidgetManager#requestPinAppWidget(android.content.ComponentName,%20android.os.Bundle,%20android.app.PendingIntent)
- https://developer.android.com/develop/ui/views/appwidgets/layouts
- https://github.com/DrKLO/Telegram/blob/master/TMessagesProj/src/main/java/org/telegram/messenger/XiaomiUtilities.java
