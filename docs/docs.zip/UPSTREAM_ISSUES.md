# 上游 issue 检查

检查日期：2026-10-23。范围：santirodriguez/CountAway 的全部公开 issue，排除了同一 API 返回的 PR。共2条实际 issue。

| Issue | 上游状态与内容 | ezCD 的处理 |
| --- | --- | --- |
| [#31](https://github.com/santirodriguez/CountAway/issues/31) | 已关闭：从桌面添加小组件时，配置页只显示最前面3个事件且不能滚动。作者确认在1.2.0修复。 | 未把上游已修复问题冒充本次新修复。重写配置页使用系统 MODE_DROPDOWN Spinner，其弹出列表原生支持滚动；外层是 ScrollView。系统桌面选择器入口仍可用，不依赖桌面支持应用内固定小组件。需要在真实桌面用超过3个事件进一步验收。 |
| [#29](https://github.com/santirodriguez/CountAway/issues/29) | 仍开放的功能请求：正数日，以及时分秒精确计数。作者确认正数日已在1.2.2实现，时分秒未在当前主分支提供。 | 1.0.1按用户新要求移除正数/倒数模式选择，统一按日期判断过去/未来，保留计入当日。本版仍是日期级计数，未实现时分秒计时，不宣称关闭或彻底解决这条 issue。 |

没有向上游发评论、提交 PR 或关闭 issue。基线为克隆时的 main，具体 SHA 记录在根目录 UPSTREAM.md。未把其他 release 分支中的未发布功能自动并入 ezCD。
