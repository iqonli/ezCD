# 1.0.17 验证记录

2026-10-25（北京时间）。Gradle 9.6.1 / AGP 9.2.1 / JDK 17 / SDK 35 / Build Tools 36.0.0。versionName 1.0.17 / versionCode 18，沿用原签名，没有新增运行依赖。

Debug、Release 构建与 lint 通过。Lint 0 错误、1411 警告（包含既有生成尺寸定义及历史未使用资源警告）。132 个生产 Kotlin 文件的源文件、XML、语言键、许可证校验及尺寸生成器校验通过。

完整回归 393 项（普通 JVM 264，Robolectric API33 界面与存储 129），0 失败、0 错误、0 跳过。保留原 390 项，增加 3 项；排版库删除菜单索引随新增项更新。新增覆盖：带自定义排版的回调序列化、排版只保存到新小组件且不覆盖事件默认排版、完成清理后重复回调仍幂等；占位不依赖事件，实际 provider 渲染的 ezCD+ 点按打开 WidgetConfigActivity 并带正确 widget ID；库入口的静态预览、无事件添加及旋转恢复。第二轮测试使用实际占位 RemoteViews 点按验证。占位文本自动缩放以适应小尺寸。

本版面向不提供小组件重配置入口的桌面：库入口在添加前选择排版，成功回调应用冻结副本；占位提供整块点按编辑入口。原有 configure/reconfigurable 支持的长按编辑保留，但无法强制厂商桌面提供菜单。本轮未在 MIUI 真机验证新的占位和排版库添加流程，权限、网格读取及尺寸仍有 DESKTOP_PIN_SIZE.md 中的平台限制。

发布前执行 tools/optimize-release.py：比较优化前后全部资源 ID、配置、值，仅忽略折叠名称；其余 ZIP 条目逐字节一致。所有尺寸和字重定义保留。v2/v3 签名、证书指纹、16 KiB 对齐和 ZIP CRC 通过，无 INTERNET 权限、不可调试、无测试字体。源码排除构建缓存、私钥、APK 与 local.properties。

APK：782914 字节。SHA256：2dcd2074787b7256a3d746e437944c66c01d45b334323768b191419208f74b05

证书 SHA256：d672ccba0f93424c5638f39ccee5ed24e8056e7ced76f0acc11377fa0c76e628

前版记录见 VALIDATION-1.0.16.md，功能说明见 PLACEHOLDER_AND_LIBRARY_PIN.md。
