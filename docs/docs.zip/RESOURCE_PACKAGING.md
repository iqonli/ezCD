1.0.17 继续使用以下资源精简流程，版本号正常推进。

# APK 资源精简（1.0.16 同版本重编译）

沿用原签名、versionName 1.0.16 和 versionCode 17。未修改应用逻辑或界面。

Release 已通过 R8 和资源裁剪去除不可达资源。APK 中的大量 XML 来自添加到桌面的尺寸预设：1–16 格两轴共 256 种组合，每种分别有旧系统和 Android 12+ 定义，共 512 份，不能按名称相似直接删除。另有 1000 个原生字重样式，供字重 1–1000 使用。

本次在 Release 构建后、对齐及签名前，使用 Android Build Tools 36.0.0 AAPT2 折叠资源名称、合并相同简单资源表条目。保留全部 id 名称，其他应用资源使用固定 ID 引用；源码中的按名称查找仅针对 android 系统资源。保留各语言、屏幕密度和系统版本配置，不启用稀疏编码，不删除尺寸或字重定义。

复现：先运行 `./gradlew :app:assembleRelease`，再执行：

```sh
python tools/optimize-release.py --aapt2 "$ANDROID_HOME/build-tools/36.0.0/aapt2" app/build/outputs/apk/release/app-release-unsigned.apk app/build/outputs/apk/release/app-release-compact-unsigned.apk
```

随后对 compact-unsigned.apk 运行 zipalign，再使用原签名运行 apksigner。勿把未签名中间包用于分发。

脚本比较优化前后的资源 ID、配置及值，仅忽略被折叠的名称；比较所有其他 ZIP 条目内容逐字节一致，并验证 ZIP CRC。不需要删除仍被使用的 res 文件来缩小资源表。

参考：https://developer.android.com/tools/aapt2#optimize
