# Gradle 9.6.1 构建工具调整

本次按现有 Gradle 9.6.1、Android Studio Quail 1（2026.1.1）、Studio 自带 JBR 21 配置工程。应用版本为1.0.8；本次未增加应用运行依赖。

| 项目 | 配置 |
| --- | --- |
| Gradle Wrapper | 9.6.1，bin 发行版 |
| Android Gradle Plugin | 9.2.1 |
| Kotlin | 使用 AGP 内置支持，不另行应用 Kotlin Android 插件 |
| Gradle 运行 JDK | 使用已有 JBR 21；最低17 |
| Java / Kotlin 字节码 | 17 |
| compileSdk / targetSdk / minSdk | 35 / 34 / 26 |
| SDK Build Tools | AGP 9.2 默认要求36.0.0 |

AGP 9.2 的最低 Gradle 为9.4.1，9.6.1高于此最低要求；Quail 1 的 AGP 支持范围到9.2。因此这里选9.2.1，而不跟着 Gradle 版本任意升级 AGP。已用 Gradle 9.6.1 成功执行 `help`、`:app:assembleDebug`、`:app:assembleRelease` 和 `:app:testDebugUnitTest`。完整构建及运行验证范围见 VALIDATION.md。

## 复用本机安装

1. 打开解压后的 ezCD 目录，保留 Android Studio 设置中现有的 Gradle user home；不要清空 T 盘缓存。
2. Gradle JDK 保持 `GRADLE_LOCAL_JAVA_HOME` / `jbr-21`，确认指向 Studio 自带 JBR 21。无须使用 E 盘旧 JDK。
3. 若9.6.1的 bin 发行版已在该 Gradle user home 的 Wrapper 缓存中，Distribution 继续选择 Wrapper。若已有的是 all 发行版或单独解压的9.6.1，选择 Local installation 并指向它的根目录。命令行脚本可用 `EZCD_GRADLE` 指向实际 `bin/gradle.bat`。
4. 先用 `build-local.bat` 离线编译；它不会下载 Gradle，也不会获取缺失依赖。缺包时先阅读具体错误，决定是否联网补齐。Android Studio 的离线模式也不会阻止首次 Wrapper 发行版下载，确保发行版本身已经存在或使用 Local installation。
5. 缓存齐备后产物仍为 `app/build/outputs/apk/debug/app-debug.apk`。

AGP 内置 Kotlin 仍会解析 Kotlin 编译器及标准库；删除单独插件声明不等于完全不下载 Kotlin。已有 Gradle 也不能保证 AGP、SDK Platform 35 或 Build Tools 36.0.0 已存在。此调整不要求 NDK、CMake、Compose、AppCompat 或 Material Components。

## 官方参考

- Android Studio / AGP / Gradle 兼容表：https://developer.android.com/build/releases/about-agp
- AGP 9.2 发布说明（含9.2.1）：https://developer.android.com/build/releases/agp-9-2-0-release-notes
- AGP 内置 Kotlin 迁移：https://developer.android.com/build/migrate-to-built-in-kotlin
- Gradle 9.6.1 发布说明：https://docs.gradle.org/9.6.1/release-notes.html
